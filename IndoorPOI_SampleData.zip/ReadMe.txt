To restore database containing sample data in pgAdmin III,

Create new database
Right click new database > Restore