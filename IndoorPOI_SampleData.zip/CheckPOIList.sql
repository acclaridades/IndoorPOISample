﻿SELECT "IndoorPOI_Basic"."InPOI_Name", "IndoorPOI_Basic"."InPOI_CategoryCode", "IndoorPOI_Basic"."InPOI_ID", "IndoorPOI_Basic"."InPOI_SpatialDepth","IndoorPOI_Basic"."parent"
	FROM "IndoorPOI_Basic"
	